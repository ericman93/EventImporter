$(function () {
    setEmailInputs();
});
